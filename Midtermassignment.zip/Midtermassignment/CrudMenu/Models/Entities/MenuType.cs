﻿namespace CrudMenu.Models.Entities
{
    public class MenuType
    {
        public int MenuTypeId { get; set; }
        public string MenuTypeName { get; set; } 
    }
}
